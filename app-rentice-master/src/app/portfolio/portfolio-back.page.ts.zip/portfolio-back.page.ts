import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Platform, AlertController, LoadingController, IonInfiniteScroll } from '@ionic/angular';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { GlobalProvider } from '../services/global-provider';
import { IonItemSliding } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { GoogleAnalytics } from '@ionic-native/google-analytics/ngx';
import {
  File
} from '@ionic-native/file/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { TranslateService } from '@ngx-translate/core';

import * as _ from 'lodash';
import * as jspdf from 'jspdf'; 
import html2canvas from 'html2canvas';
import 'jspdf-autotable';

declare var ga;
declare var window;

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.page.html',
  styleUrls: ['./portfolio.page.scss'],
})
export class PortfolioPage implements OnInit {

	data: any = {};
	user: any = {};
	bLoadPortfolio: any;
	portfolioList: any = [];
	totalCount: any = 0;
	AllPortfolioList: any = [];
  portfolioItemList: any;
  AllPortfolioItemList: any = [];
  currentPortfolio: any;
  bLoaded: boolean = false;

  tableHtml: string = '';
  photoList: any;
  listCnt: any = 0;
  exportList: any = [];
  pdf: any;
  exportLoading: any;

	@ViewChild(IonInfiniteScroll) infiniteScroll: IonInfiniteScroll;

  constructor(private platform: Platform,
              private translate: TranslateService,
              public alertController: AlertController,
              public loadingController: LoadingController,
              private http: HttpClient,
              private router: Router,
              public file: File,
              private storage: Storage,
              private socialSharing: SocialSharing,
              private cdRef: ChangeDetectorRef,
              private ga: GoogleAnalytics,
              public global: GlobalProvider) { }

  ngOnInit() {
    this.tableHtml = '<thead><tr>\
        <th class="photo">Name</th>\
        <th class="photo">Photo1</th>\
        <th class="photo">Photo2</th>\
        <th class="photo">Photo3</th>\
        <th>Category/Activity</th>\
        <th>Notes</th>\
        <th>Address/Projects</th>\
        <th>Hours</th>\
        <th>Date</th>\
      </tr></thead><tbody>';
  }

	ionViewWillEnter() {
    try {
      if(!window.device) {
        window.ga('send', 'pageview', 'Portfolio Page');
      } else {
        if(this.ga) {
          this.ga.trackView('Portfolio Page');
        }
      }
    } catch(e) {
      console.log(e)
    }
    
    this.bLoaded = false;
  	console.log("==portfolio page===");
  	this.user = JSON.parse(localStorage.getItem("user"));
    this.currentPortfolio = JSON.parse(localStorage.getItem("currentPortfolio"));

    this.infiniteScroll.disabled = false;
    this.loadUserData();
    this.data.status = 'All';

    this.loadPortfolioItems();
 	}

  async exportPDF() {
    this.exportList = _.cloneDeep(this.portfolioItemList);
    this.pdf = new jspdf('p', 'px', 'a4'); // A4 size page of PDF
    this.exportLoading = await this.loadingController.create({
      message: this.translate.instant('Exporting as PDF...'),
    });
    await this.exportLoading.present();
    this.tableHtml = '<thead><tr>\
        <th>Name</th>\
        <th>Photo 1</th>\
        <th>Photo 2</th>\
        <th>Photo 3</th>\
        <th>Category/Activity</th>\
        <th>Notes</th>\
        <th>Project</th>\
        <th>Hrs</th>\
        <th>Date</th>\
      </tr></thead><tbody>';
    this.photoList = [];
    this.listCnt = 0;
    this.doExport(true);
  }

  exportPDFCordova(pdfOutput, pdfName) {
    // using ArrayBuffer will allow you to put image inside PDF
    let buffer = new ArrayBuffer(pdfOutput.length);
    let array = new Uint8Array(buffer);
    for (var i = 0; i < pdfOutput.length; i++) {
        array[i] = pdfOutput.charCodeAt(i);
    }

    let directory = '';
    // For this, you have to use ionic native file plugin
    //const directory = this.file.externalApplicationStorageDirectory ;

    if(this.platform.is('android') == true) {
        directory = this.file.externalDataDirectory;  
    } else {
        directory = this.file.dataDirectory;
    }

    const fileName = pdfName;

    this.file.writeFile(directory, fileName, buffer)
    .then((success)=> {
      console.log("File created Succesfully" + JSON.stringify(success));
      this.socialSharing.share("ROW Pdf file for sharing", "ROW pdf", directory + fileName, null);
    })
    .catch((error)=> {
      console.log("Cannot Create File " +JSON.stringify(error));
      this.global.displayAlert("Cannot create pdf file.");
    });
  }

  doExport(flag = false) {
    if(this.exportList.length < 1) {
      //debugger
      console.log(this.photoList);

      this.tableHtml += '</tbody>';

      setTimeout(() => {
          this.pdf.autoTable({html: '#my-table15',
            columnStyles: {
              0: {cellWidth: 50},
              1: {halign: 'center', minCellWidth:60, minCellHeight: 60}, 
              2: {halign: 'center', minCellWidth:60, minCellHeight: 60}, 
              3: {halign: 'center', minCellWidth:60, minCellHeight: 60}}, // Cells in first column centered and green
              4: {cellWidth: 50},
              5: {minCellWidth: 50},
              6: {cellWidth: 50},
              7: {minCellWidth: 40, cellWidth: 40},
              8: {minCellWidth: 50, cellWidth: 40},
            didDrawCell: data => {
              //console.log(data);
              if(data.section === 'body') {
                //console.log(data.cell);
                try {
                  if (parseInt(data.column.index) === 1) {
                     var base64Img = this.photoList[data.row.index][0];
                     if(base64Img)
                       this.pdf.addImage(base64Img, 'JPG', data.cell.x + 2, data.cell.y + 2, 60, 60);
                  }
                  if (parseInt(data.column.index) === 2) {
                     var base64Img = this.photoList[data.row.index][1];
                     if(base64Img)
                       this.pdf.addImage(base64Img, 'JPG', data.cell.x + 2, data.cell.y + 2, 60, 60);
                  }
                  if (parseInt(data.column.index) === 3) {
                     var base64Img = this.photoList[data.row.index][2];
                     if(base64Img)
                       this.pdf.addImage(base64Img, 'JPG', data.cell.x + 2, data.cell.y + 2, 60, 60);
                  }
                } catch(e) {

                }
              }
            }
          });

        this.exportLoading.dismiss();
        let pdfName = "Portfolio_Item_" + new Date().getTime() + ".pdf";
        if(this.global.isCordova) {
          let pdfOutput = this.pdf.output();
          this.exportPDFCordova(pdfOutput, pdfName);
        } else {
          this.pdf.save(pdfName);
        }
        return ;
      }, 0);
      return ;
    }
    if(flag != true) {
      //this.pdf.addPage();
    }
    let pdfItem = this.exportList[0];
    let mainCat = "";
    this.global.allMaincategoryList.forEach((item) => {
      if(item.cat == pdfItem.main_category) {
        mainCat = item.name;
        return ;
      }
    });
    let subCat = "";
    this.global.allSubcategoryList.forEach((item) => {
      if(parseInt(item.list_id) == parseInt(pdfItem.sub_category) ||
        parseInt(item.cat) == parseInt(pdfItem.sub_category)) {
        subCat = item.name;
        return ;
      }
    });

    let imageList = [];
    if(pdfItem.photo.length > 0) {
      imageList.push(pdfItem.photo);
    }
    if(pdfItem.photo2 && pdfItem.photo2.length > 0) {
      imageList.push(pdfItem.photo2);
    }
    if(pdfItem.photo3 && pdfItem.photo3.length > 0) {
      imageList.push(pdfItem.inventory_image3);
    }

    let n = 0;
    let width = this.pdf.internal.pageSize.getWidth();
    let height = this.pdf.internal.pageSize.getHeight();

    this.tableHtml += '<tr>';
    this.tableHtml += '<td>' + pdfItem.name + '</td>';
    this.photoList[this.listCnt] = [];
    if(imageList.length > 0) {
      for(let i=0;i<imageList.length;i++){
        this.global.toDataURL('https://www.artisanideas.co.nz/itab/database/styled/' + imageList[i], (dataUrl) => {
         if(dataUrl != null && dataUrl.indexOf("data:image") > -1) {
           if(this.photoList[this.listCnt])
             this.photoList[this.listCnt].push(dataUrl);
           this.tableHtml += '<td><img style="min-width:80px" src="' + dataUrl + '" /></td>';
         } else {
           if(this.photoList[this.listCnt])
             this.photoList[this.listCnt].push(null);
           this.tableHtml += '<td><img src="https://www.google.com/logos/doodles/2016/user-birthday-5656109189693440.4-s.png" /></td>';
         }
         n++;
          
         if(n >= imageList.length) {
            for(let j=0;j<3-imageList.length;j++) {
              this.tableHtml += '<td><img src="https://www.google.com/logos/doodles/2016/user-birthday-5656109189693440.4-s.png" /></td>';
              if(this.photoList[this.listCnt])
                this.photoList[this.listCnt].push(null);
            }
            this.tableHtml += '<td><div>' + mainCat + '</div><div>' + subCat + '</div><div>';
            this.tableHtml += pdfItem.activity + '</div><div>' + pdfItem.activity2 + '</div><div>';
            this.tableHtml += pdfItem.activity3 + '</div><div></div><div></div></td>';

            this.tableHtml += '<td>' + pdfItem.notes.replace(/(\r\n|\n|\r)/gm," ") + '</td>';
            this.tableHtml += '<td>' + pdfItem.address + '</td>';
            this.tableHtml += '<td>' + pdfItem.value + '</td>';
            this.tableHtml += '<td>' + pdfItem.created + '</td>';
            this.tableHtml += '</tr>';
            this.listCnt++;
            this.exportList.shift();
            this.doExport();
         }
        });
      }   
    } else {
      for(let j=0;j<3;j++) {
        this.tableHtml += '<td><img src="https://www.google.com/logos/doodles/2016/user-birthday-5656109189693440.4-s.png" /></td>';
        if(this.photoList[this.listCnt])
            this.photoList[this.listCnt].push(null);
      }
      this.tableHtml += '<td><div>' + mainCat + '</div><div>' + subCat + '</div><div>';
      this.tableHtml += pdfItem.activity + '</div><div>' + pdfItem.activity2 + '</div><div>';
      this.tableHtml += pdfItem.activity3 + '</div><div></div><div></div></td>';

      this.tableHtml += '<td>' +  pdfItem.notes.replace(/(\r\n|\n|\r)/gm," ") + '</td>';
      this.tableHtml += '<td>' + pdfItem.address + '</td>';
      this.tableHtml += '<td>' + pdfItem.value + '</td>';
      this.tableHtml += '<td>' + pdfItem.created + '</td>';
      this.tableHtml += '</tr>';
      this.listCnt++;
      this.exportList.shift();
      this.doExport();
    }
  }

 	loadUserData() {
      this.data.tutor = this.user.tutor;
      this.data.user_id = this.user.user_id;
      this.data.faculty = this.user.faculty;
      this.data.provider = this.user.provider;
  }

	statusFilter(item) {
    console.log(item.status);
    return this.data.status == 'All' || item.status == this.data.status
  }

  async loadPortfolioItems() {
      this.portfolioItemList = [];
      const url = "https://www.artisanideas.co.nz/api/app-rentice/get_all_portfolio_item.php" ;
      const loading = await this.loadingController.create({
        message: '',
      });
      await loading.present();
      this.http.get(url).subscribe((resp: any) => {
          this.bLoaded = true;
          loading.dismiss();
          console.log(resp.data);
          if(resp.error == true) {
              this.global.displayAlert("There is an error when get portfolio.");
              return ;
          }
          
          resp.data.forEach(item => {
            item.name = this.user.user_firstname + " " + this.user.user_lastname;
          });
          resp.data.forEach(item => {
            if(item.list_no == this.currentPortfolio.list_id) {
              this.AllPortfolioItemList.push(item)
            }
          })
          this.totalCount = this.AllPortfolioItemList.length;
          if(this.infiniteScroll)
            this.infiniteScroll.disabled = false;
          // if(this.totalCount > 10) {
          //     this.portfolioList = this.AllPortfolioItemList.slice(0, 10);
          // } else {
          //     this.portfolioList = this.AllPortfolioItemList;
          // }
          this.portfolioItemList = this.AllPortfolioItemList;
      }, (err) => {
          this.bLoaded = true;
          loading.dismiss();
          this.global.displayAlert("There is an error when get todo list.");
      }); 
  }

	loadMore(event) {
    //Load More 10 items
    if(this.portfolioList === null || this.portfolioList === undefined) {
        return ;
    }
    var nCount = this.portfolioList.length;
    var moreList = [];
    if(nCount+10>this.totalCount) {
        var n = this.totalCount - nCount;
        moreList = this.AllPortfolioList.slice(nCount, nCount+n);
    } else {
        moreList = this.AllPortfolioList.slice(nCount, nCount+10);
    }
    
    this.portfolioList = this.portfolioList.concat(moreList);
    this.infiniteScroll.disabled = false;
    if(this.portfolioList.length >= this.totalCount) {
        this.infiniteScroll.disabled = true;
    }
    event.target.complete();
  }

  goPortfolioItem(slidingItem: IonItemSliding, item) {
      if(slidingItem)
        slidingItem.close();
      localStorage.setItem("currentPortfolioItem", JSON.stringify(item));
    	console.log(item);  
     	this.router.navigateByUrl('/edit-portfolio');
  }
}
